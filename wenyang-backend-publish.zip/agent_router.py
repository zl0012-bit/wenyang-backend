#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Agent 确定性调度主函数。

run_agent(user_input, has_image, current_page, image_path=None)
    ├─ classify_intent → qa / comparison / redesign / other
    ├─ qa | comparison : rag_search 召回 → glm-4-flash 基于检索资料生成回答
    ├─ redesign         : 若有图 → 视觉工具链（extract_color + segment_pattern）→ 结构化 JSON
    │                     若无图 → 提示上传图片
    └─ other            : 通用对话（glm-4-flash / 离线兜底）

返回统一结构（与后端接口对齐）：
    {
      "intent": str, "confidence": float, "reason": str,
      "answer": str,
      "tool_results": {...},     # vision 或 rag 的中间产物
      "sources": [...]          # qa/comparison 的检索来源
    }
"""
import os
import re
import logging

import zhipu_client as zhipu
import intent_router as ir
import rag_search as rs
import vision_tools as vt

logger = logging.getLogger("agent_router")

QA_SYS = (
    "你是「纹以载道」传统纹样数字博物馆的问答助手。"
    "请严格依据下方【检索资料】作答，禁止编造资料之外的具体史实或引用；"
    "若资料不足，请如实说明并给出可进一步检索的方向。用简洁、专业的中文回答。"
)


# --------------------------------------------------------------------------- #
# 回答合成（真实 LLM 优先，离线用检索资料拼接兜底）
# --------------------------------------------------------------------------- #
def _offline_answer(query: str, chunks: list) -> str:
    lines = [f"根据知识库检索，为你找到 {len(chunks)} 枚相关纹样："]
    for c in chunks:
        m = c["metadata"]
        lines.append(f"· {c['name']}（{m['origin_std']}｜{m['theme']}）— 相似度 {c['similarity_score']}")
    lines.append("\n（离线模式未接入大模型，以上为检索命中；配置 ZHIPU_API_KEY 后可生成自然语言解读。）")
    return "\n".join(lines)


def _synthesize_qa(query: str, chunks: list, soften: bool = False) -> str:
    ctx = "\n\n".join(
        f"【纹样 {c['name']}】朝代:{c['metadata']['origin_std']} 主题:{c['metadata']['theme']}\n{c['content']}"
        for c in chunks
    )
    if zhipu.MODE == "real":
        sys_p = QA_SYS
        if soften:
            # 命中相似度偏低：模型直接基于资料自然接续，引导句由代码硬拼在前面，保证稳定出现
            sys_p += (
                "\n注意：以下检索资料的相似度偏低，并非完全精准匹配。"
                "请直接基于资料给出尽量契合的纹样推荐，语气自然；"
                "不要在开头重复任何引导句，直接接正文即可。"
            )
        ans = zhipu.chat_text(sys_p, f"检索资料：\n{ctx}\n\n用户问题：{query}\n请作答。")
        if soften and ans:
            return SOFTEN_PREFIX + ans
        return ans or _offline_answer(query, chunks)
    if soften:
        return SOFTEN_PREFIX + _offline_answer(query, chunks)
    return _offline_answer(query, chunks)


def _collect_best(trace: list, result: dict):
    """汇总全程所有 rag_search / reformulate 命中，挑出 top-1 分数最高的那次作为『最佳命中』。"""
    rag_traces = [t for t in trace
                  if t["tool"] in ("rag_search", "reformulate_query(auto)", "reformulate_query")
                  and isinstance(t.get("obs"), list) and t["obs"]]
    best_chunks, best_top = None, -1.0
    for t in rag_traces:
        obs = t["obs"]
        top = obs[0]["similarity_score"] if obs else -1.0
        if top > best_top:
            best_top, best_chunks = top, obs
    if not best_chunks:
        best_chunks = (result["tool_results"].get("rag") or {}).get("chunks", [])
    return best_chunks, best_top


def _synthesize_comparison(query: str, chunks: list) -> str:
    # comparison：把两端纹样都喂给模型对比，离线则列出来源
    return _synthesize_qa(query, chunks)


def _describe_vision(colors: dict, segs: dict) -> str:
    dom = colors.get("dominant")
    top = "、".join(f"{p['hex']}({int(p['ratio'] * 100)}%)" for p in colors.get("palette", [])[:3])
    return (
        f"已对该纹样完成视觉分析。主色调 {dom}，前 3 主色占比：{top}；"
        f"边缘连通域切分出 {segs.get('num_components', 0)} 个图层，"
        f"可用于分层再设计 / 配色提取。"
    )


# --------------------------------------------------------------------------- #
# 主函数
# --------------------------------------------------------------------------- #
def run_agent(user_input: str, has_image: bool = False, current_page=None,
              image_path: str = None) -> dict:
    user_input = (user_input or "").strip()
    intent = ir.classify_intent(user_input, has_image=has_image, current_page=current_page)
    intent_name = intent["intent"]

    result = {
        "intent": intent_name,
        "confidence": intent.get("confidence"),
        "reason": intent.get("reason"),
        "answer": "",
        "tool_results": {},
        "sources": [],
    }

    try:
        if intent_name in ("qa", "comparison"):
            chunks = rs.rag_search(user_input, top_k=5)
            result["sources"] = [
                {
                    "pattern_id": c["pattern_id"],
                    "name": c["name"],
                    "theme": c["metadata"]["theme"],
                    "origin_std": c["metadata"]["origin_std"],
                    "category_group": c["metadata"]["category_group"],
                    "score": c["similarity_score"],
                }
                for c in chunks
            ]
            result["tool_results"]["rag"] = {
                "count": len(chunks),
                "top": result["sources"][:3],
            }
            result["answer"] = (
                _synthesize_comparison(user_input, chunks)
                if intent_name == "comparison"
                else _synthesize_qa(user_input, chunks)
            )

        elif intent_name == "redesign":
            if not image_path:
                result["answer"] = (
                    "已识别为「纹样再设计」需求。请上传一张纹样图片，"
                    "我将自动提取主色板并做图层切分，返回结构化结果。"
                )
            else:
                colors = vt.extract_color(image_path)
                segs = vt.segment_pattern(image_path)
                result["tool_results"]["vision"] = {
                    "extract_color": colors,
                    "segment_pattern": segs,
                }
                result["answer"] = _describe_vision(colors, segs)

        else:  # other
            if zhipu.MODE == "real":
                result["answer"] = zhipu.chat_text(
                    "你是博物馆的智能助手，负责轻松自然地回应访客。", user_input
                ) or "（暂无法生成回答）"
            else:
                result["answer"] = (
                    "（通用对话：离线模式未接入大模型，已识别为 other 意图。）"
                )
    except Exception as e:
        logger.exception("run_agent 执行异常")
        result["answer"] = f"处理出错：{e}"
        result["error"] = str(e)

    return result


# =========================================================================== #
# ReAct 自主决策链路（隔离新增，不替换上面的确定性 run_agent）
#
# 设计原则：
#  - 与 run_agent 完全独立，前端不传 mode=react 时绝不会走到这里；
#  - max_steps 上限防止模型无限循环；
#  - 检索最高相似度 < REFORMULATE_THRESHOLD(0.55) 时自动「换词重试」；
#  - 每轮思考/工具调用/观察都打印 [ReAct] 日志，方便联调观察多轮决策；
#  - 即便步数耗尽，也会抽取全程「最高分命中」强行合成回答，不再返回冰冷兜底。
# =========================================================================== #
REACT_SYS = (
    "你是「纹以载道」传统纹样数字博物馆的多步推理助手（ReAct 范式：Reasoning + Acting）。\n"
    "你可以通过调用工具来逐步收集信息，再给出最终回答。可用工具：\n"
    "  - rag_search：在纹样知识库中向量检索（适用于查找/了解/对比纹样）\n"
    "  - extract_color / segment_pattern：对纹样图片做视觉分析（需图片路径）\n"
    "  - reformulate_query：当检索结果不理想时，换一种表述重新检索\n"
    "决策规则：\n"
    "  1) 若信息已足够，直接以自然语言作答，不再调用工具；\n"
    "  2) 若需要更多信息，调用合适的工具；\n"
    "  3) 若一次检索命中不相关（相似度低），主动 reformulate_query 换词重试；\n"
    "  4) 严格依据检索到的资料作答，不编造资料之外的史实。\n"
    "回答要简洁、专业、面向博物馆访客。"
)

# 换词重试触发阈值：RAG 命中最高相似度低于此值即认为检索不理想。
# 已由 0.65 下调到 0.55：多数"宽泛/古老"类问题在 0.55~0.65 区间其实已有可用命中，
# 过早换词反而容易把模型带进 reformulate 死循环。
REFORMULATE_THRESHOLD = 0.55

# 温和兜底前缀阈值：全程最佳命中低于此值，最终回答前加 SOFTEN_PREFIX 作诚实引导。
# 取 0.62（高于换词阈值 0.55）：意味着"已换词重试、命中尚可但不算精准"的查询
# （典型如 C1『古老吉祥纹样』）也会以温和口吻呈现，而非冷冰冰的兜底。
SOFTEN_THRESHOLD = 0.62
SOFTEN_PREFIX = "虽然未找到完全精准匹配的，但以下是契合吉祥寓意的古老纹样……\n\n"

# —— ReAct 工具 Schema（OpenAI 风格，与 VISION_TOOLS 合并）——
RAG_SEARCH_SCHEMA = {
    "type": "function",
    "function": {
        "name": "rag_search",
        "description": "在 574 枚传统纹样知识库中做向量检索，返回最相关的若干纹样"
                       "（含名称、朝代、主题、文化寓意与相似度）。适用于查找/了解/对比某类纹样。",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "检索关键词或问题，例如 '明清 红色 牡丹纹'"},
                "dynasty_filter": {"type": "string", "description": "可选『单一』朝代过滤，如 '汉'/'唐'/'宋'/'魏晋'（只填一个，不要组合成 '唐宋明清' 这类多朝代串，否则可能无结果）；不填则不限"},
                "theme_filter": {"type": "string", "description": "可选主题过滤，如 'mingqing'/'明清·繁缛红'，不填则不限"},
            },
            "required": ["query"],
        },
    },
}
REFORMULATE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "reformulate_query",
        "description": "当上一次检索结果不理想（相似度偏低、命中不相关）时，换一种表述/角度重新提问以再次检索。",
        "parameters": {
            "type": "object",
            "properties": {
                "new_query": {"type": "string", "description": "改写后的检索词，保留朝代/主题/纹样名等实体"},
            },
            "required": ["new_query"],
        },
    },
}
REACT_TOOLS = [RAG_SEARCH_SCHEMA, REFORMULATE_SCHEMA] + vt.VISION_TOOLS


def _obs_to_text(obs) -> str:
    """把一个工具观测结果序列化为可回填给模型的短文本。"""
    if isinstance(obs, list):  # rag_search 返回 chunk 列表
        if not obs:
            return "（检索无结果）"
        lines = []
        for i, c in enumerate(obs[:5], 1):
            m = c["metadata"]
            lines.append(f"[{i}] {c['name']}（{m['origin_std']}｜{m['theme']}）score={c['similarity_score']}：{c['content'][:120]}")
        return "\n".join(lines)
    return str(obs)[:300]


def _reformulate_query(query: str, trace: list) -> str:
    """LLM 改写检索词：基于已有不理想检索，产出更精准的关键词串。

    关键优化：当用户强调「古老 / 不要近现代 / 古代」时，强制让大模型在改写结果里
    显式补上具体朝代实体（汉、魏晋、唐、宋、元），而不是干巴巴地换同义词，
    否则"古老"二字的向量语义太发散，容易检索到明清反而偏离用户本意。
    """
    obs_text = "\n".join(f"- {o['tool']}({o.get('args')}) -> {o.get('summary', '')[:120]}" for o in trace[-3:])

    era_hint = ""
    if re.search(r"古老|古代|不要近现代|非近现代|不是近现代|传统|古典|很久以前", query):
        era_hint = (
            "用户明确强调要「古老 / 非近现代」的纹样，请在改写时强制加入具体朝代实体词"
            "（如 汉、魏晋、魏晋南北朝、唐、宋、元），优先选用更靠前的朝代，"
            "并尽量保留「吉祥/寓意/纹样」等主题词，以提升检索精准度。"
        )
        logger.info("[ReAct] 重写注入朝代限定：检测到'古老/非近现代'，强制携带汉/唐/宋/魏晋等实体词")

    sys_p = ("你是检索词改写器。基于已有检索结果的不佳表现，给出更精准的检索关键词串，"
             "务必保留朝代、主题、纹样名等实体词。"
             + era_hint +
             "只输出改写后的文本，不要解释。")
    new_q = zhipu.chat_text(sys_p, f"原问题：{query}\n已有检索：\n{obs_text}\n请给出更精准的检索词：")
    return (new_q or "").strip() or query


def _execute_react_tool(name, args, image_path, result):
    """执行单个工具调用，并把关键产物写回 result['tool_results']。返回观测结果（回填给模型）。"""
    args = args or {}
    if name == "rag_search":
        chunks = rs.rag_search(
            args.get("query", ""),
            dynasty_filter=args.get("dynasty_filter"),
            theme_filter=args.get("theme_filter"),
            top_k=5,
        )
        result["tool_results"]["rag"] = {"count": len(chunks), "query": args.get("query", ""), "chunks": chunks}
        result["sources"] = [
            {
                "pattern_id": c["pattern_id"], "name": c["name"], "theme": c["metadata"]["theme"],
                "origin_std": c["metadata"]["origin_std"], "category_group": c["metadata"]["category_group"],
                "score": c["similarity_score"],
            } for c in chunks
        ]
        return chunks

    if name in ("extract_color", "segment_pattern"):
        p = args.get("image_path") or image_path
        if p and os.path.exists(p):
            r = getattr(vt, name)(p)
            result["tool_results"].setdefault("vision", {})[name] = r
            return r
        return {"error": "no image available"}

    if name == "reformulate_query":
        # ★ 关键修复：reformulate_query 必须真正重新检索，否则模型反复调用它却永远拿不到
        #   新结果，3 步耗尽后命中冰冷兜底（C1 死循环的根因）。这里直接以新 query 复检。
        new_q = args.get("new_query") or user_input
        logger.info("[ReAct] 执行 reformulate_query 工具：以 %r 重新检索", new_q)
        chunks = rs.rag_search(new_q, top_k=5)
        result["tool_results"]["rag"] = {
            "count": len(chunks), "query": new_q, "chunks": chunks, "reformulated": True
        }
        result["sources"] = [
            {"pattern_id": c["pattern_id"], "name": c["name"], "theme": c["metadata"]["theme"],
             "origin_std": c["metadata"]["origin_std"], "category_group": c["metadata"]["category_group"],
             "score": c["similarity_score"]} for c in chunks
        ]
        return {"reformulated_to": new_q, "retrieved": _obs_to_text(chunks)}

    return {"error": f"unknown tool: {name}"}


def run_agent_react(user_input: str, has_image: bool = False, current_page=None,
                    image_path: str = None, max_steps: int = 3) -> dict:
    """ReAct 多轮自主决策链路（与 run_agent 隔离，互不影响）。

    参数
    ----
    max_steps : 最大决策步数（默认 3，防无限循环）。
    """
    logger.info("[ReAct] 启动：问题=%r | has_image=%s | max_steps=%s", user_input, has_image, max_steps)
    user_input = (user_input or "").strip()
    result = {
        "intent": None, "confidence": None, "reason": None,
        "answer": "", "tool_results": {"react_trace": []}, "sources": [], "mode": "react",
    }

    # 离线 mock：无 LLM 驱动，直接确定性检索兜底，避免空转
    if zhipu.MODE != "real":
        logger.warning("[ReAct] 离线 mock 模式：跳过 LLM 多轮决策，直接确定性检索兜底")
        chunks = rs.rag_search(user_input, top_k=5)
        result["tool_results"]["rag"] = {"count": len(chunks), "query": user_input, "chunks": chunks}
        result["sources"] = [
            {"pattern_id": c["pattern_id"], "name": c["name"], "theme": c["metadata"]["theme"],
             "origin_std": c["metadata"]["origin_std"], "category_group": c["metadata"]["category_group"],
             "score": c["similarity_score"]} for c in chunks
        ]
        result["answer"] = _offline_answer(user_input, chunks)
        return result

    intent = ir.classify_intent(user_input, has_image=has_image, current_page=current_page)
    result["intent"] = intent["intent"]
    result["confidence"] = intent.get("confidence")
    result["reason"] = intent.get("reason")

    trace = result["tool_results"]["react_trace"]
    reformulated = False

    for step in range(1, max_steps + 1):
        obs_block = "\n".join(f"第{o['step']}步 工具={o['tool']} 结果=\n{o.get('summary', '')}" for o in trace) or "（暂无）"
        user_msg = (
            f"用户问题：{user_input}\n"
            f"意图：{intent['intent']}\n"
            f"已完成的工具调用与结果：\n{obs_block}\n\n"
            f"若已收集到足够信息，请只输出面向访客的最终回答"
            f"（不要复述本指令、不要出现『下一步』『直接作答』等元描述）；"
            f"若仍需信息，则调用合适的工具"
            f"（rag_search / extract_color / segment_pattern / reformulate_query）。"
            + (f"\n注意：待分析图片的本地路径为 {image_path}" if image_path else "")
        )
        logger.info("[ReAct] 第 %d/%d 步：思考中…", step, max_steps)
        decision = zhipu.chat_tools(REACT_SYS, user_msg, tools=REACT_TOOLS, temperature=0.2)
        content = decision.get("content")
        tool_calls = decision.get("tool_calls") or []

        if not tool_calls:
            logger.info("[ReAct] 第 %d 步：模型决定结束，产出最终回答", step)
            if content:
                # 命中偏弱时，用检索资料重新合成带温和前缀的回答，而非直出模型原话
                best_chunks, best_top = _collect_best(trace, result)
                if best_top < SOFTEN_THRESHOLD:
                    logger.info("[ReAct] 早期结束但最佳命中偏低(top=%.3f<%.2f)，改用温和兜底合成", best_top, SOFTEN_THRESHOLD)
                    synth = _synthesize_qa(user_input, best_chunks, soften=True)
                    result["answer"] = synth or content
                else:
                    result["answer"] = content
            break

        for tc in tool_calls:
            name, args = tc["name"], tc.get("arguments", {})
            logger.info("[ReAct] 第 %d 步：调用工具 %s(%s)", step, name, args)
            obs = _execute_react_tool(name, args, image_path, result)
            summary = _obs_to_text(obs)
            logger.info("[ReAct] 观察：%s -> %s", name, summary[:160].replace("\n", " "))
            trace.append({"step": step, "tool": name, "args": args, "obs": obs, "summary": summary})

            # ★ 换词重试触发逻辑：RAG 命中最高相似度 < 阈值，且尚未 reformulate
            if name == "rag_search" and isinstance(obs, list) and obs and not reformulated:
                top_score = obs[0]["similarity_score"]
                if top_score < REFORMULATE_THRESHOLD:
                    logger.info("[ReAct] 换词重试：top_score=%.3f < %.2f，触发 reformulate", top_score, REFORMULATE_THRESHOLD)
                    new_q = _reformulate_query(user_input, trace) or user_input
                    logger.info("[ReAct] 换词重试：%r -> %r", user_input, new_q)
                    chunks2 = rs.rag_search(new_q, top_k=5)
                    result["tool_results"]["rag"] = {"count": len(chunks2), "query": new_q, "chunks": chunks2, "reformulated": True}
                    result["sources"] = [
                        {"pattern_id": c["pattern_id"], "name": c["name"], "theme": c["metadata"]["theme"],
                         "origin_std": c["metadata"]["origin_std"], "category_group": c["metadata"]["category_group"],
                         "score": c["similarity_score"]} for c in chunks2
                    ]
                    summary2 = _obs_to_text(chunks2)
                    trace.append({"step": step, "tool": "reformulate_query(auto)", "args": {"new_query": new_q},
                                  "obs": chunks2, "summary": summary2})
                    reformulated = True

    # 兜底：走到 max_steps 仍无最终回答 → 抽取全程「最高分命中」强行合成，不再返回冰冷提示
    if not result["answer"]:
        best_chunks, best_top = _collect_best(trace, result)

        if best_chunks:
            # 低于温和阈值才加前缀；命中尚可则直接作答
            soften = best_top < SOFTEN_THRESHOLD
            logger.info("[ReAct] 步数耗尽兜底：采用全程最高分命中 top=%.3f（soften=%s），强制合成回答",
                        best_top, soften)
            result["tool_results"]["rag"] = {
                "count": len(best_chunks),
                "query": (result["tool_results"].get("rag") or {}).get("query", user_input),
                "chunks": best_chunks, "fallback_used": True,
            }
            result["sources"] = [
                {"pattern_id": c["pattern_id"], "name": c["name"], "theme": c["metadata"]["theme"],
                 "origin_std": c["metadata"]["origin_std"], "category_group": c["metadata"]["category_group"],
                 "score": c["similarity_score"]} for c in best_chunks
            ]
            ans = _synthesize_qa(user_input, best_chunks, soften=soften)
            result["answer"] = ans or _offline_answer(user_input, best_chunks)
        else:
            logger.warning("[ReAct] 步数耗尽且全程无检索命中，返回离线兜底")
            result["answer"] = "（暂未检索到相关纹样，请换个说法或补充图片后重试。）"

    return result


if __name__ == "__main__":
    import json

    print("--- qa ---")
    print(json.dumps(run_agent("帮我找找明清的红色纹样", False, "纹样宝库"), ensure_ascii=False, indent=2))
    print("--- comparison ---")
    print(json.dumps(run_agent("对比明清和宋代的龙凤纹", False, "朝代长廊"), ensure_ascii=False, indent=2))
    print("--- redesign (no image) ---")
    print(json.dumps(run_agent("用这张图帮我生成现代海报", True, "AI共创"), ensure_ascii=False, indent=2))
    print("--- redesign (with image) ---")
    print(json.dumps(run_agent("分析这张纹样的配色", True, "AI共创", "/workspace/patterns/A01.webp"), ensure_ascii=False, indent=2)[:1200])
