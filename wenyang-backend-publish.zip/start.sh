#!/usr/bin/env bash
# 本地 / 无容器环境的一键启动脚本
# 用法：  bash start.sh
set -e

# 1) 建独立 venv（避免污染系统 Python；系统 python 可能缺 zhipuai 导致静默降级）
python3 -m venv .venv 2>/dev/null || true
if [ -d .venv ]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

# 2) 装依赖
pip install -r requirements.txt

# 3) 启动（PORT 默认 8000；容器平台会覆盖）
export PORT="${PORT:-8000}"
exec python -m uvicorn main:app --host 0.0.0.0 --port "$PORT"
