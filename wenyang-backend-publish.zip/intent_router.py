#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
意图分类模块（结合现有前端页面上下文）。

四类意图：
    qa         文博问答（介绍某纹样、问寓意/工艺/朝代）
    redesign   纹样再设计（AI 共创、生成图片、改稿）
    comparison 对比考据（两个及以上朝代/纹样名 + 对比词）
    other      通用对话（闲聊、与纹样无关）

分类优先级：
    1) 前置规则拦截（确定性高、零延迟）
       - 带图片（AI共创页）            -> redesign
       - 含对比词 且 (≥2朝代 | ≥2纹样名 | 1朝代+1纹样名) -> comparison
    2) LLM 兜底：调用智谱 glm-4-flash（JSON 模式）做细粒度判定
    3) 无 Key 时的启发式兜底：保证永远有结果
"""
import os
import csv
import logging

import zhipu_client as zhipu
from rag_search import DYN_ALIAS  # 复用朝代词表，避免重复维护

logger = logging.getLogger("intent_router")

DEFAULT_CSV = os.path.join(os.path.dirname(__file__), "pattern_inventory_574.csv")
INTENTS = ("qa", "redesign", "comparison", "other")

# 对比触发词
CMP_KEYWORDS = ["区别", "对比", "比较", "差异", "异同", "不同", "分别", "pk", "PK", "比一比", "对照"]

# 再设计触发词（无图但语义明确时）
REDESIGN_KEYWORDS = ["再设计", "重新设计", "生成图", "画一张", "设计稿", "创作", "海报", "二创",
                     "变体", "改稿", "配色方案", "衍生", "文创", "logo", "LOGO"]

# 文博问答触发词（含检索/推荐类，避免「帮我找找…」被误判为 other）
QA_KEYWORDS = ["寓意", "是什么", "介绍", "工艺", "朝代", "起源", "象征", "故事", "文化", "来历",
               "怎么读", "含义", "特点", "特色", "怎么形容", "找", "推荐", "哪些", "有哪些",
               "搜", "颜色", "红色", "蓝色", "绿色", "纹样库", "适合", "用在哪里"]

# 朝代检测词（长词优先，避免「周」误命中「周期」等）
_DYN_WORDS = sorted(DYN_ALIAS.keys(), key=len, reverse=True)

# 页面语义（注入 prompt，帮助 LLM 判断）
PAGE_HINT = {
    "首页": "网站首页，用户通常在泛览或发起搜索",
    "纹样宝库": "纹样陈列/检索页，多为按朝代、主题、色彩的检索与问答",
    "朝代长廊": "按朝代浏览纹样，问题多与某朝代纹样特征相关",
    "非遗技艺馆": "非遗工艺科普页，问题多为工艺/技艺问答",
    "AI共创": "AI 创作页，用户上传图片做再设计/生成，带图必判 redesign",
}


# --------------------------------------------------------------------------- #
# 实体检测
# --------------------------------------------------------------------------- #
def _load_pattern_names(csv_path: str = DEFAULT_CSV):
    names = set()
    try:
        with open(csv_path, encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                if row.get("name"):
                    names.add(row["name"].strip())
    except Exception as e:
        logger.warning("加载纹样名失败: %s", e)
    return names


_PATTERN_NAMES = None


def _detect_dynasties(text: str):
    found = set()
    for w in _DYN_WORDS:
        if w in text:
            found.add(w)
    # 去重叠：剔除被更长命中词完全包含的短词（如 '明清' 命中后去掉 '明'/'清'）
    kept = []
    for w in sorted(found, key=len, reverse=True):
        if not any(w != k and w in k for k in kept):
            kept.append(w)
    return set(kept)


def _detect_patterns(text: str):
    global _PATTERN_NAMES
    if _PATTERN_NAMES is None:
        _PATTERN_NAMES = _load_pattern_names()
    return {n for n in _PATTERN_NAMES if n and n in text}


# --------------------------------------------------------------------------- #
# 规则拦截
# --------------------------------------------------------------------------- #
def _rule_check(text: str, has_image: bool):
    if has_image:
        return "redesign", 1.0, "请求携带图片（AI共创/再设计场景），直接判定纹样再设计"

    has_cmp = any(k in text for k in CMP_KEYWORDS)
    if has_cmp:
        dyn = _detect_dynasties(text)
        pat = _detect_patterns(text)
        if len(dyn) >= 2:
            return "comparison", 0.97, f"含对比词且出现 {len(dyn)} 个朝代（{', '.join(dyn)}）"
        if len(pat) >= 2:
            return "comparison", 0.97, f"含对比词且出现 {len(pat)} 个纹样名（{', '.join(pat)}）"
        if dyn and pat:
            return "comparison", 0.95, f"含对比词且同时出现朝代({', '.join(dyn)})与纹样名({', '.join(pat)})"

    # 纯再设计语义（无图也能判定）
    if any(k in text for k in REDESIGN_KEYWORDS):
        return "redesign", 0.9, "命中再设计语义关键词"

    return None


# --------------------------------------------------------------------------- #
# 启发式兜底（无 Key 时）
# --------------------------------------------------------------------------- #
def _heuristic(text: str):
    if any(k in text for k in REDESIGN_KEYWORDS):
        return "redesign"
    if any(k in text for k in CMP_KEYWORDS):
        return "comparison"
    if any(k in text for k in QA_KEYWORDS):
        return "qa"
    return "other"


# --------------------------------------------------------------------------- #
# LLM 兜底
# --------------------------------------------------------------------------- #
_SYS = (
    "你是「纹以载道」传统纹样数字博物馆的意图分类器。"
    "请把用户 query 归入四类之一："
    "qa（文博问答，如介绍纹样、问寓意/工艺/朝代）、"
    "redesign（纹样再设计，如 AI 生成、改稿、做文创/海报）、"
    "comparison（对比考据，如两个朝代或纹样的异同）、"
    "other（通用闲聊或与纹样无关）。"
    "只输出 JSON，格式：{\"intent\":\"qa\",\"confidence\":0.9,\"reason\":\"...\"}。"
    "intent 必须是 qa/redesign/comparison/other 之一，confidence 为 0~1 浮点数。"
)


def _llm_fallback(text: str, current_page: str | None):
    page_ctx = PAGE_HINT.get(current_page or "", "页面未知")
    user_msg = f"当前页面：{current_page or '未知'}（{page_ctx}）\n用户 query：{text}"
    out = zhipu.chat_json(_SYS, user_msg)
    if not out or out.get("intent") not in INTENTS:
        return None
    try:
        conf = float(out.get("confidence", 0.8))
    except Exception:
        conf = 0.8
    return {
        "intent": out["intent"],
        "confidence": round(conf, 2),
        "reason": str(out.get("reason", "")),
    }


# --------------------------------------------------------------------------- #
# 对外函数
# --------------------------------------------------------------------------- #
def classify_intent(user_input: str, has_image: bool = False,
                    current_page: str | None = None) -> dict:
    """
    参数
    ----
    user_input    : 用户输入文本
    has_image     : 是否携带图片（AI共创页上传）
    current_page  : 当前前端页面名（首页/纹样宝库/朝代长廊/非遗技艺馆/AI共创）

    返回
    ----
    {"intent": "qa"|"redesign"|"comparison"|"other",
     "confidence": float,
     "reason": str}
    """
    text = (user_input or "").strip()
    rule = _rule_check(text, has_image)
    if rule:
        return {"intent": rule[0], "confidence": rule[1], "reason": rule[2]}

    if zhipu.MODE == "real":
        res = _llm_fallback(text, current_page)
        if res:
            return res

    # 无 Key / LLM 失败：启发式兜底
    intent = _heuristic(text)
    return {
        "intent": intent,
        "confidence": 0.6,
        "reason": "无 API Key（或 LLM 调用失败），使用规则启发式兜底" if zhipu.MODE != "real"
                  else "LLM 返回不合法，回退启发式",
    }


if __name__ == "__main__":
    samples = [
        ("帮我找找明清的红色纹样", False, "纹样宝库"),
        ("苗族纹样有什么特色", False, "纹样宝库"),
        ("对比明清和宋代的龙凤纹", False, "朝代长廊"),
        ("用这个纹样帮我生成一张现代海报", True, "AI共创"),
        ("缠枝莲的寓意和工艺介绍一下", False, "非遗技艺馆"),
        ("你好", False, "首页"),
    ]
    for q, img, page in samples:
        print(q, "->", classify_intent(q, img, page))
