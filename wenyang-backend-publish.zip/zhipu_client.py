#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统一智谱客户端：embedding-3（向量化）+ glm-4-flash（LLM）。

设计要点：
- 所有大模型调用统一走这里，Key 从环境变量 ZHIPU_API_KEY 读取。
- 未配置 Key 时自动进入「mock 模式」：
  * embed  → 基于字 bi-gram 的确定性哈希向量（本地、可复现），足以支撑离线冒烟测试；
  * chat   → 返回 None，由调用方走规则/启发式兜底。
- 真实模式与 mock 模式的对外接口完全一致，业务代码无需感知。
"""
import os
import re
import json
import hashlib
import logging
import numpy as np

logger = logging.getLogger("zhipu_client")

# —— 启动时从 .env 自动加载环境变量（含 ZHIPU_API_KEY）——
# 这样后端无需依赖终端临时 `export`，部署更稳，Key 也不会进进程命令行参数。
# 失败则静默降级为「纯环境变量」模式（行为不变）。
try:
    from dotenv import load_dotenv
    # 明确指向本模块同目录的 .env，避免受运行目录影响
    _env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    load_dotenv(_env_path)
except Exception:
    pass

EMBEDDING_MODEL = "embedding-3"
CHAT_MODEL = "glm-4-flash"

API_KEY = os.environ.get("ZHIPU_API_KEY", "").strip()
_MODE = "real" if API_KEY else "mock"

_client = None
if _MODE == "real":
    try:
        from zhipuai import ZhipuAI
        _client = ZhipuAI(api_key=API_KEY)
    except Exception as e:  # 极端情况：Key 配了但 SDK 不可用 → 退回 mock
        _MODE = "mock"
        _client = None
        _import_error = e

MODE = _MODE


# --------------------------------------------------------------------------- #
# 向量化
# --------------------------------------------------------------------------- #
def _mock_embed(texts, dim: int = 1024):
    """离线向量：字 bi-gram + TF 加权 + L2 归一化。中文同字会自然产生词面重叠。"""
    out = []
    for t in texts:
        vec = np.zeros(dim, dtype=np.float32)
        grams = [t[i:i + 2] for i in range(len(t) - 1)] or [t]
        for g in grams:
            h = int(hashlib.md5(g.encode("utf-8")).hexdigest(), 16)
            vec[h % dim] += 1.0
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        out.append(vec.tolist())
    return out


def embed(texts, batch_size: int = 32):
    """texts: list[str] -> list[list[float]]（L2 归一化）。"""
    if isinstance(texts, str):
        texts = [texts]
    texts = [str(t) for t in texts]

    if _MODE != "real":
        return _mock_embed(texts)

    try:
        out = []
        for i in range(0, len(texts), batch_size):
            chunk = texts[i:i + batch_size]
            resp = _client.embeddings.create(model=EMBEDDING_MODEL, input=chunk)
            out.extend([d.embedding for d in resp.data])
        return out
    except Exception as e:
        # Key 失效/过期/网络抖动时降级为本地哈希向量，保证检索服务不挂
        logger.warning("embedding 调用失败，降级为本地哈希向量: %s", e)
        return _mock_embed(texts)


# --------------------------------------------------------------------------- #
# 文本生成（可选 JSON 模式）
# --------------------------------------------------------------------------- #
def _extract_json(text: str):
    """从模型输出中尽量稳健地解析出 JSON 对象。"""
    if text is None:
        return None
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            return None
    return None


def chat_text(system: str, user: str, temperature: float = 0.1) -> str | None:
    """自由文本生成（用于 Query Rewrite 之类）。无 Key 或调用失败均返回 None。"""
    if _MODE != "real":
        return None
    try:
        resp = _client.chat.completions.create(
            model=CHAT_MODEL,
            temperature=temperature,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        return resp.choices[0].message.content
    except Exception as e:
        # Key 失效/过期/网络抖动时降级为 None，由调用方走规则兜底，避免整条链路 500
        logger.warning("chat_text 调用失败（已降级为兜底）: %s", e)
        return None


def chat_json(system: str, user: str, temperature: float = 0.1) -> dict | None:
    """JSON 模式生成（用于意图分类兜底）。无 Key 或调用失败均返回 None。"""
    if _MODE != "real":
        return None
    try:
        resp = _client.chat.completions.create(
            model=CHAT_MODEL,
            temperature=temperature,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        return _extract_json(resp.choices[0].message.content)
    except Exception as e:
        logger.warning("chat_json 调用失败（已降级为兜底）: %s", e)
        return None


def chat_tools(system: str, user: str, tools: list,
               tool_choice: str = "auto", temperature: float = 0.2,
               history: list = None) -> dict:
    """
    Function-Calling 封装（OpenAI 风格 tools，智谱 GLM 兼容）。

    用于 ReAct 自主决策：模型可返回 0~N 个 tool_calls，由调用方执行后再回填。
    返回结构（与调用方约定稳定）:
        {
          "content": str | None,        # 模型的最终自然语言（无工具调用时）
          "tool_calls": [               # 本次需执行的工具调用列表
             {"name": str, "arguments": dict}, ...
          ],
          "finish_reason": str | None,  # "tool_calls" / "stop" / ...
        }

    mock 模式（无 Key 或 SDK 不可用）直接返回空 tool_calls，由调用方走确定性兜底，
    绝不抛出、绝不 500。
    """
    if _MODE != "real":
        return {"content": None, "tool_calls": [], "finish_reason": None}

    try:
        messages = [{"role": "system", "content": system}]
        if history:
            messages.extend(history)
        messages.append({"role": "user", "content": user})

        resp = _client.chat.completions.create(
            model=CHAT_MODEL,
            temperature=temperature,
            tools=tools,
            tool_choice=tool_choice,
            messages=messages,
        )
        msg = resp.choices[0].message
        tool_calls = []
        for tc in (msg.tool_calls or []):
            try:
                args = json.loads(tc.function.arguments) if tc.function.arguments else {}
            except Exception:
                args = {}
            tool_calls.append({"name": tc.function.name, "arguments": args})
        return {
            "content": msg.content,
            "tool_calls": tool_calls,
            "finish_reason": resp.choices[0].finish_reason,
        }
    except Exception as e:
        logger.warning("chat_tools 调用失败（已降级为无工具兜底）: %s", e)
        return {"content": None, "tool_calls": [], "finish_reason": None}


if __name__ == "__main__":
    print("MODE =", MODE)
    v = embed(["明清 红色 纹样", "苗族 银饰"])
    print("embed dim =", len(v[0]), "samples =", len(v))
