# 纹以载道 · 后端（FastAPI + ChromaDB + 智谱 GLM）

## 目录
```
backend/
├── main.py              # FastAPI 入口，提供 /api/agent_chat、/health
├── zhipu_client.py      # 智谱 GLM-4-Flash / embedding-3 调用封装
├── agent_router.py      # 确定性 RAG (run_agent) + ReAct 多轮 (run_agent_react)
├── rag_search.py        # ChromaDB 检索（DEFAULT_PERSIST=chroma_db）
├── vision_tools.py      # OpenCV 本地视觉（主色提取 / 图层切分）
├── intent_router.py     # 意图识别
├── rebuild_index.py     # 重建向量库脚本（数据更新时跑）
├── requirements.txt     # 依赖（已锁定版本，实测可跑）
├── Dockerfile           # Render / Railway 通用
├── render.yaml          # Render Blueprint 一键部署
├── start.sh             # 本地/无容器启动
├── .env.example         # 环境变量样例（复制为 .env 后填 Key）
├── chroma_db/           # ✅ 已预建向量库（部署即用，无需重新 embedding）
└── data/                # 原始数据（CSV / JSON / 标签）
```

## 快速启动（本地）
```bash
bash start.sh            # 自动建 venv、装依赖、起 uvicorn :8000
# 或手动：
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env     # 填入 ZHIPU_API_KEY
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

## 部署（Render 为例）
1. 推到 GitHub；Render → New → Web Service → Docker → 选本仓库。
2. Health Check Path：`/health`。
3. Environment 加 `ZHIPU_API_KEY=你的Key`。
4. Deploy → 得到 `https://xxx.onrender.com`。

## 接口
- `GET  /health` → `{"status":"ok"}`
- `POST /api/agent_chat`
  ```json
  {"user_input":"...","current_page":"纹样宝库","has_image":false,"mode":"default|react"}
  ```
  表单模式（带图）：`user_input` / `current_page` / `image`(文件) / `mode`

## 备注
- CORS 已设 `allow_origins=["*"]`，前端可跨域直连。
- `chroma_db` 由 `chromadb==1.5.9` 构建，请勿随意升级 chromadb。
- 数据更新后：`python rebuild_index.py` 重新建库（需智谱 Key 做 embedding）。
